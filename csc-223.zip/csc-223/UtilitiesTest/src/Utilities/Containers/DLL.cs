// Built in C# exceptions
System.Exception;

// DNode class that can store any value
public class DNode<T>
{
    public T Value;
    public DNode<T> Left;
    public DNode<T> Right;
    public DNode(T Value)
    {
        this.Value = Value;
        this.Left = null;
        this.Right = null;
    }
}

// DLL class
public class DLL<T> : IEnumerable<T>, IList<T>
{
    public T head;
    public T tail;
    public int size;
    public DLL()
    {
        // Initialize the class with sentinel nodes
        this.head = DNode < T >
        this.tail = DNode < T >
        this.head.Right = tail;
        this.tail.Left = head;
        this.size = 0;
    }

    // Void? or none?
    private void Insert(DNode node, T item)
    {
        // Make the new item a DNode
        DNode<T> newnode = new DNode<T>(item);
        // If the size is 0, insert between head and tail
        if (size == 0)
        {
            newnode.Left = head;
            newnode.Right = tail;
            head.Right = newnode;
            tail.Left = newnode;
        }
        else
        {
            newnode.Left = node.Left;
            newnode.Right = node;
            node.Left.Right = newnode;
            node.Left = newnode;
        }
        // Increase size
        size++;
    }

    private void Remove(DNode node)
    {
        // What to return with this exception if its voide
        // if (node == head || node == tail)
        else
        {
            node.Left.Right = node.Right;
            node.Right.Left = node.Left;
            size--;
        }

    }

    private DNode GetNode(int index)
    {
        // Start at first valid node
        DNode<T> start = head.Right;
        int i = 0;
        if (index < 0 || index >= size) throw ArgumentOutOfRangeException;
        else
        {
            while (start != tail)
            {
                // If i = index, return the node, else keep going through the list
                if (i == index) return start;
                else
                {
                    start = start.Right;
                    i++;
                }
            }
        }
    }

    public bool Contains(T item)
    {
        DNode<T> start = head.Right;
        for (int i = 0; i < size; i++)
        {
            // Use equality comparer because of type T
            if (start.Value.Equals(item)) return true;
            else
            {
                start = start.Right;
            }
        }
        return false;
    }

    public int Size()
    {
        return size;
    }

    // String rep of DLL, debugging
    public string ToString()
    {
        DLL = DLL.ToString();
        return DLL;
    }

    // Remove first occurence of an item
    public bool Remove(T item)
    {
        DNode<T> start = head.Right;
        for (int i = 0; i < size; i++)
        {
            if (start.Value.Equals(item))
            {
                Remove(item);
                // Make sure to leave the loop after the first remove
                break;
            }
            else
            {
                start = start.Right;
            }
            return true;
        }
        return false;
    }

    // Returns the element stored at the first valid node
    public T Front()
    {
        if (size == 0) throw InvalidOperationException;
        else
        {
            return head.next.Value;
        }
    }
}

