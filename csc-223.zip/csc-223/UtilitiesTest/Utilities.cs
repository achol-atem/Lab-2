using System;

namespace UtilitiesTest
{
    /// <summary>
    /// Custom exception for empty string scenarios
    /// </summary>
    public class EmptyStringException : Exception
    {
        public EmptyStringException() : base("Level must be greater than 0") { }
        public EmptyStringException(string message) : base(message) { }
        public EmptyStringException(string message, Exception innerException) : base(message, innerException) { }
    }

    /// <summary>
    /// Utility class providing common helper methods
    /// </summary>

    public class Utilities
    {
        public string GetIndentation(int level)
        {
            if (level <= 0) throw new EmptyStringException();
            string spaces = " ";
            for (int i = 0; i < (level * 4) - 1; i++)
            {
                spaces += " ";
            }
            return spaces;
        }

        public bool Contains<T>(T[] array, T item)
        {
            for (int i = 0; i < array.Length; i++)
            {  
                if (EqualityComparer<T>.Default.Equals(array[i], item))
                return true;
            }
        return false; 
        }

        public string ToCamelCase(string s)
        {
            string result = "";
            result += char.ToLower(s[0]);
            for (int index = 1; index < s.Length; index++)
            {
                if (s[index] == ' ')
                {   
                    if (index + 1 < s.Length)
                    {
                        result += char.ToUpper(s[index+1]);
                        index ++;
                    }
                }
                else result += s[index];
            }
            
        
            return result;
        }
       

        public bool IsPasswordStrong(string pwd)
        {
            if (pwd.Length < 8) return false;
            bool hasUppercase = pwd.Any(char.IsUpper);
            bool hasLowercase = pwd.Any(char.IsLower);
            bool hasDigit = pwd.Any(char.IsDigit);
            bool hasSpecial = pwd.Any(c => !char.IsLetterOrDigit(c) && !char.IsWhiteSpace();
        
        return hasUppercase && hasLowercase && hasDigit && hasSpecial;
        }

        public bool IsValidVariable(string name)
        {
            char current_char = name[i];
            for (int i = 0; i < name.Length; i++) ;
            {
                if (char.IsUpper(current_char)) ;
                {
                    return False;
                }
            }
        }
    }
}