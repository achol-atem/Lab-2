﻿using System;
using System.Linq;
using Xunit;

namespace UtilitiesTest.Tests
{
    /// <summary>
    /// Comprehensive test suite for the Utilities class
    /// Created by Claude - Anthropic AI Assistant
    /// </summary>
    public class UtilitiesTests
    {
        private readonly Utilities _utilities;

        public UtilitiesTests()
        {
            _utilities = new Utilities();
        }

        #region Theory Tests - Multiple Input Scenarios

        [Theory]
        [InlineData(1, 4)]
        [InlineData(2, 8)]
        [InlineData(3, 12)]
        [InlineData(4, 16)]
        [InlineData(5, 20)]
        [InlineData(10, 40)]
        [InlineData(15, 60)]
        [InlineData(25, 100)]
        public void GetIndentation_ValidLevels_ReturnsCorrectSpaceCount(int level, int expectedLength)
        {
            // Act
            string result = _utilities.GetIndentation(level);

            // Assert
            Assert.Equal(expectedLength, result.Length);
            Assert.True(result.All(c => c == ' '), $"All characters should be spaces for level {level}");
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        [InlineData(-5)]
        [InlineData(-10)]
        [InlineData(-100)]
        [InlineData(int.MinValue)]
        public void GetIndentation_InvalidLevels_ThrowsEmptyStringException(int level)
        {
            // Act & Assert
            var exception = Assert.Throws<EmptyStringException>(() => _utilities.GetIndentation(level));
            Assert.NotNull(exception);
            Assert.Contains("Level must be greater than 0", exception.Message);
        }

        [Theory]
        [InlineData(1, "    ")]        // 4 spaces
        [InlineData(2, "        ")]    // 8 spaces
        [InlineData(3, "            ")] // 12 spaces
        public void GetIndentation_SpecificLevels_ReturnsExpectedSpaces(int level, string expectedSpaces)
        {
            // Act
            string result = _utilities.GetIndentation(level);

            // Assert
            Assert.Equal(expectedSpaces, result);
            Assert.Equal(level * 4, result.Length);
        }

        [Theory]
        [InlineData(50)]
        [InlineData(100)]
        [InlineData(200)]
        public void GetIndentation_LargeLevels_ReturnsCorrectLength(int level)
        {
            // Arrange
            int expectedLength = level * 4;

            // Act
            string result = _utilities.GetIndentation(level);

            // Assert
            Assert.Equal(expectedLength, result.Length);
            Assert.True(result.All(c => c == ' '), "All characters should be spaces");
        }

        [Theory]
        [InlineData(1)]
        [InlineData(5)]
        [InlineData(10)]
        [InlineData(20)]
        public void GetIndentation_ValidLevels_NeverReturnsNullOrEmpty(int level)
        {
            // Act
            string result = _utilities.GetIndentation(level);

            // Assert
            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.True(result.Length > 0);
        }

        #endregion

        #region Fact Tests - Specific Single Scenarios

        [Fact]
        public void GetIndentation_Level1_Returns4Spaces()
        {
            // Act
            string result = _utilities.GetIndentation(1);

            // Assert
            Assert.Equal("    ", result);
            Assert.Equal(4, result.Length);
            Assert.True(result.All(c => c == ' '));
        }

        [Fact]
        public void GetIndentation_Level2_Returns8Spaces()
        {
            // Act
            string result = _utilities.GetIndentation(2);

            // Assert
            Assert.Equal("        ", result);
            Assert.Equal(8, result.Length);
            Assert.True(result.All(c => c == ' '));
        }

        [Fact]
        public void GetIndentation_MinimumValidLevel_ReturnsCorrectSpaces()
        {
            // Arrange
            int level = 1; // Minimum valid level

            // Act
            string result = _utilities.GetIndentation(level);

            // Assert
            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.Equal(4, result.Length);
            Assert.Equal("    ", result);
        }

        [Fact]
        public void GetIndentation_Zero_ThrowsEmptyStringException()
        {
            // Act & Assert
            var exception = Assert.Throws<EmptyStringException>(() => _utilities.GetIndentation(0));
            Assert.NotNull(exception);
            Assert.IsType<EmptyStringException>(exception);
        }

        [Fact]
        public void GetIndentation_NegativeOne_ThrowsEmptyStringException()
        {
            // Act & Assert
            var exception = Assert.Throws<EmptyStringException>(() => _utilities.GetIndentation(-1));
            Assert.NotNull(exception);
            Assert.IsType<EmptyStringException>(exception);
        }

        [Fact]
        public void GetIndentation_ReturnsOnlySpaceCharacters()
        {
            // Arrange
            int level = 7;

            // Act
            string result = _utilities.GetIndentation(level);

            // Assert
            foreach (char c in result)
            {
                Assert.Equal(' ', c);
            }
            Assert.DoesNotContain('\t', result);
            Assert.DoesNotContain('\n', result);
            Assert.DoesNotContain('\r', result);
        }

        [Fact]
        public void GetIndentation_ConsistentResults_SameLevelReturnsSameOutput()
        {
            // Arrange
            int level = 5;

            // Act
            string result1 = _utilities.GetIndentation(level);
            string result2 = _utilities.GetIndentation(level);
            string result3 = _utilities.GetIndentation(level);

            // Assert
            Assert.Equal(result1, result2);
            Assert.Equal(result2, result3);
            Assert.Equal(result1, result3);
        }

        [Fact]
        public void GetIndentation_DifferentLevels_ProduceDifferentLengths()
        {
            // Act
            string level1Result = _utilities.GetIndentation(1);
            string level2Result = _utilities.GetIndentation(2);
            string level3Result = _utilities.GetIndentation(3);

            // Assert
            Assert.True(level1Result.Length < level2Result.Length);
            Assert.True(level2Result.Length < level3Result.Length);
            Assert.Equal(4, level2Result.Length - level1Result.Length);
            Assert.Equal(4, level3Result.Length - level2Result.Length);
        }

        [Fact]
        public void GetIndentation_ExceptionHasCorrectMessage()
        {
            // Act & Assert
            var exception = Assert.Throws<EmptyStringException>(() => _utilities.GetIndentation(0));
            Assert.Equal("Level must be greater than 0", exception.Message);
        }

        [Fact]
        public void GetIndentation_LargeLevel_PerformanceTest()
        {
            // Arrange
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            int level = 100;

            // Act
            string result = _utilities.GetIndentation(level);
            stopwatch.Stop();

            // Assert
            Assert.True(stopwatch.ElapsedMilliseconds < 1000, "Method should complete within 1 second");
            Assert.Equal(400, result.Length);
            Assert.True(result.All(c => c == ' '));
        }

        #endregion

        #region EmptyStringException Tests

        [Fact]
        public void EmptyStringException_DefaultConstructor_HasCorrectMessage()
        {
            // Act
            var exception = new EmptyStringException();

            // Assert
            Assert.Equal("Level must be greater than 0", exception.Message);
        }

        [Fact]
        public void EmptyStringException_CustomMessage_HasCorrectMessage()
        {
            // Arrange
            string customMessage = "Custom error message";

            // Act
            var exception = new EmptyStringException(customMessage);

            // Assert
            Assert.Equal(customMessage, exception.Message);
        }

        [Fact]
        public void EmptyStringException_WithInnerException_HasCorrectProperties()
        {
            // Arrange
            string message = "Test message";
            var innerException = new ArgumentException("Inner exception");

            // Act
            var exception = new EmptyStringException(message, innerException);

            // Assert
            Assert.Equal(message, exception.Message);
            Assert.Equal(innerException, exception.InnerException);
        }

        #endregion
    }
}

/*
 * ============================================================================
 * NAMESPACE STRUCTURE EXPLANATION
 * Created by Claude - Anthropic AI Assistant
 * ============================================================================
 * 
 * CORRECTED STRUCTURE FOR FOLDER: "utilitiestest"
 * 
 * MAIN CLASS FILE (Utilities.cs):
 * - Namespace: UtilitiesTest
 * - Classes: EmptyStringException, Utilities
 * - Location: utilitiestest/Utilities.cs
 * 
 * TEST FILE (UtilitiesTests.cs):
 * - Namespace: UtilitiesTest.Tests
 * - Class: UtilitiesTests
 * - Location: utilitiestest/UtilitiesTests.cs
 * 
 * NAMING CONVENTIONS USED:
 * ✓ Pascal case for namespaces (UtilitiesTest, UtilitiesTest.Tests)
 * ✓ Pascal case for class names (Utilities, UtilitiesTests)
 * ✓ Folder name "utilitiestest" converted to Pascal case "UtilitiesTest"
 * ✓ Clear separation between main code and test code namespaces
 * 
 * CURRENT FOLDER STRUCTURE:
 * utilitiestest/
 * ├── Utilities.cs (namespace UtilitiesTest)
 * └── UtilitiesTests.cs (namespace UtilitiesTest.Tests)
 * 
 * ALTERNATIVE OPTIONS:
 * 
 * Option 1 - Keep folder name as namespace:
 * - Namespace: utilitiestest (lowercase - not recommended)
 * 
 * Option 2 - Separate projects:
 * utilitiestest/
 * ├── Utilities.cs (namespace UtilitiesTest)
 * utilitiestest.Tests/
 * └── UtilitiesTests.cs (namespace UtilitiesTest.Tests)
 * 
 * Option 3 - More descriptive:
 * - Main: UtilitiesTest.Core
 * - Tests: UtilitiesTest.Core.Tests
 * 
 * The structure provided follows .NET conventions by converting the folder 
 * name to proper Pascal case for the namespace.
 */